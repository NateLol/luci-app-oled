void testdrawline();
void testdrawrect();
void testfillrect();
void testdrawcircle();
void testdrawroundrect();
void testfillroundrect();
void testdrawtriangle();
void testfilltriangle();
void testdrawchar();
void testscrolltext(char *str);
void display_texts();
void display_bitmap();
void display_invert_normal();
void testdrawbitmap(const unsigned char *bitmap, unsigned char w, unsigned char h);
void testdrawbitmap_eg();
void deeplyembedded_credits();
void testprintinfo();
void testdate(int standalone);
void testlanip(int standalone);
void testcpufreq(int standalone);
void testcputemp(int standalone);
void testnetspeed(int standalone);

 
